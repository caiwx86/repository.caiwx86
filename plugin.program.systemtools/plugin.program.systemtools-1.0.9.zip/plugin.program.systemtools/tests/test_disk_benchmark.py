# -*- coding: utf-8 -*-
"""Unit tests for DiskBenchmarkTool."""

import os
from unittest.mock import MagicMock
from resources.lib.tools.disk_benchmark import DiskBenchmarkTool


def test_sequential_write_and_read(tmp_path):
    tool = DiskBenchmarkTool()
    bench_file = os.path.join(str(tmp_path), "test_bench.tmp")
    mock_dp = MagicMock()
    mock_dp.is_canceled.return_value = False

    # Test sequential write (2 MB for quick test)
    write_speed = tool._test_sequential_write(bench_file, size_mb=2, dp=mock_dp)
    assert write_speed > 0
    assert os.path.exists(bench_file)
    assert os.path.getsize(bench_file) == 2 * 1024 * 1024

    # Test sequential read
    read_speed = tool._test_sequential_read(bench_file, dp=mock_dp)
    assert read_speed > 0

    # Test 4k random write (50 ops)
    iops_w, mbs_w = tool._test_4k_random_write(bench_file, size_mb=2, dp=mock_dp, ops=50)
    assert iops_w > 0
    assert mbs_w > 0

    # Test 4k random read (50 ops)
    iops_r, mbs_r = tool._test_4k_random_read(bench_file, size_mb=2, dp=mock_dp, ops=50)
    assert iops_r > 0
    assert mbs_r > 0

    # Test cleanup
    tool._cleanup_temp_file(bench_file)
    assert not os.path.exists(bench_file)


def test_flush_and_evict_cache(tmp_path):
    tool = DiskBenchmarkTool()
    dummy_file = os.path.join(str(tmp_path), "cache_test.tmp")
    with open(dummy_file, "wb") as f:
        f.write(b"DATA" * 1024)
    tool._flush_and_evict_cache(dummy_file)
    assert os.path.exists(dummy_file)
    os.remove(dummy_file)


def test_disk_benchmark_cancellation_and_edge_cases(tmp_path):
    tool = DiskBenchmarkTool()
    bench_file = os.path.join(str(tmp_path), "test_cancel.tmp")
    mock_dp = MagicMock()
    mock_dp.is_canceled.return_value = True

    # Sequential write canceled immediately
    write_speed = tool._test_sequential_write(bench_file, size_mb=2, dp=mock_dp)
    assert write_speed >= 0

    # 4k random write with 0 size
    iops_w, mbs_w = tool._test_4k_random_write(bench_file, size_mb=0, dp=mock_dp)
    assert iops_w == 0.0 and mbs_w == 0.0

    # 4k random read with 0 size
    iops_r, mbs_r = tool._test_4k_random_read(bench_file, size_mb=0, dp=mock_dp)
    assert iops_r == 0.0 and mbs_r == 0.0

    tool._cleanup_temp_file(bench_file)


def test_parse_fio_json_valid():
    tool = DiskBenchmarkTool()
    sample_write_json = """
    {
      "fio version" : "fio-3.41",
      "jobs" : [
        {
          "jobname" : "seq_write",
          "write" : {
            "bw_bytes" : 104857600,
            "iops" : 100.0,
            "clat_ns" : {
              "percentile" : {
                "95.000000" : 1500000
              }
            }
          },
          "read" : {
            "bw_bytes" : 0,
            "iops" : 0.0
          }
        }
      ]
    }
    """
    bw_mb, iops, lat_ms = tool._parse_fio_json(sample_write_json, mode="write")
    assert round(bw_mb, 1) == 100.0
    assert round(iops, 1) == 100.0
    assert round(lat_ms, 2) == 1.50

    sample_read_json = """
    {
      "fio version" : "fio-3.41",
      "jobs" : [
        {
          "jobname" : "rand_read",
          "read" : {
            "bw_bytes" : 52428800,
            "iops" : 12800.0,
            "clat_ns" : {
              "percentile" : {
                "95.000000" : 800000
              }
            }
          }
        }
      ]
    }
    """
    bw_mb, iops, lat_ms = tool._parse_fio_json(sample_read_json, mode="read")
    assert round(bw_mb, 1) == 50.0
    assert round(iops, 1) == 12800.0
    assert round(lat_ms, 2) == 0.80


def test_parse_fio_json_invalid():
    tool = DiskBenchmarkTool()
    bw_mb, iops, lat_ms = tool._parse_fio_json("not valid json", mode="write")
    assert bw_mb == 0.0
    assert iops == 0.0
    assert lat_ms == 0.0

    bw_mb, iops, lat_ms = tool._parse_fio_json("{}", mode="read")
    assert bw_mb == 0.0
    assert iops == 0.0
    assert lat_ms == 0.0


def test_get_fio_binary_unsupported_platform(monkeypatch):
    tool = DiskBenchmarkTool()
    from resources.lib.common.os_detect import OSType
    monkeypatch.setattr(tool.sys_info, "os_type", OSType.WINDOWS)
    assert tool._get_fio_binary() is None

    monkeypatch.setattr(tool.sys_info, "os_type", OSType.ANDROID)
    assert tool._get_fio_binary() is None


def test_get_fio_binary_supported_platform(monkeypatch, tmp_path):
    tool = DiskBenchmarkTool()
    from resources.lib.common.os_detect import OSType
    monkeypatch.setattr(tool.sys_info, "os_type", OSType.COREELEC)

    fake_fio = os.path.join(str(tmp_path), "fake_fio")
    with open(fake_fio, "w") as f:
        f.write("#!/bin/sh\nexit 0\n")

    monkeypatch.setattr(tool, "_probe_fio", lambda path: "fio-3.41" if path == fake_fio else None)
    monkeypatch.setattr(tool, "_find_bundled_fio", lambda: fake_fio)

    result = tool._get_fio_binary()
    assert result is not None
    bin_path, ver = result
    assert bin_path == fake_fio
    assert ver == "fio-3.41"


def test_run_fio_cmd_success(monkeypatch):
    tool = DiskBenchmarkTool()
    mock_dp = MagicMock()
    mock_dp.is_canceled.return_value = False

    class FakeProc:
        def __init__(self):
            self.poll_count = 0
            self.returncode = 0

        def poll(self):
            self.poll_count += 1
            return 0 if self.poll_count >= 2 else None

        def communicate(self):
            return '{"fake": true}', ""

    monkeypatch.setattr("subprocess.Popen", lambda *args, **kwargs: FakeProc())
    out = tool._run_fio_cmd(["fake_fio"], mock_dp, 10, 50, "testing")
    assert out == '{"fake": true}'
    assert mock_dp.update.called


def test_run_fio_cmd_cancellation(monkeypatch):
    tool = DiskBenchmarkTool()
    mock_dp = MagicMock()
    mock_dp.is_canceled.return_value = True

    class FakeProc:
        def poll(self):
            return None

        def terminate(self):
            pass

        def wait(self, timeout=None):
            pass

    monkeypatch.setattr("subprocess.Popen", lambda *args, **kwargs: FakeProc())
    out = tool._run_fio_cmd(["fake_fio"], mock_dp, 10, 50, "testing")
    assert out is None


def test_full_run_with_fio_engine(monkeypatch, tmp_path):
    tool = DiskBenchmarkTool()
    monkeypatch.setattr(tool, "_select_target_directory", lambda title: str(tmp_path))
    monkeypatch.setattr(tool, "_select_test_size", lambda title: 64)
    monkeypatch.setattr(tool, "_get_fio_binary", lambda: ("/bin/fio", "3.41"))

    # Mock fio json outputs for 4 steps
    def fake_run_fio_cmd(cmd, dp, start, end, label):
        if "seq_write" in cmd[1]:
            return '{"jobs":[{"jobname":"seq_write","write":{"bw_bytes":104857600,"iops":100}}]}'
        elif "seq_read" in cmd[1]:
            return '{"jobs":[{"jobname":"seq_read","read":{"bw_bytes":209715200,"iops":200}}]}'
        elif "rand_write" in cmd[1]:
            return '{"jobs":[{"jobname":"rand_w","write":{"bw_bytes":52428800,"iops":5000,"clat_ns":{"percentile":{"95.000000":2500000}}}}]}'
        elif "rand_read" in cmd[1]:
            return '{"jobs":[{"jobname":"rand_r","read":{"bw_bytes":62914560,"iops":6000,"clat_ns":{"percentile":{"95.000000":1200000}}}}]}'
        return None

    monkeypatch.setattr(tool, "_run_fio_cmd", fake_run_fio_cmd)
    viewer_called = {}

    def mock_viewer(title, text):
        viewer_called["title"] = title
        viewer_called["text"] = text

    monkeypatch.setattr("resources.lib.tools.disk_benchmark.dialog_textviewer", mock_viewer)

    tool.run({})
    assert "text" in viewer_called
    report = viewer_called["text"]
    assert "Engine: fio 3.41" in report
    assert "Sequential Write: 100.00 MB/s" in report
    assert "Sequential Read: 200.00 MB/s" in report
    assert "4K Random Write: 50.00 MB/s (5000 IOPS)" in report
    assert "4K Write Latency (p95): 2.50 ms" in report
    assert "4K Random Read: 60.00 MB/s (6000 IOPS)" in report
    assert "4K Read Latency (p95): 1.20 ms" in report


