#!/usr/bin/python
# -*- coding: utf-8 -*-


BASEITEM_COLUMNS = {
    'id': {
        'data': 'TEXT PRIMARY KEY',
        'indexed': True
    },
    'mediatype': {
        'data': 'TEXT',
    },
    'expiry': {
        'data': 'INTEGER',
        'indexed': True
    },
    'datalevel': {
        'data': 'INTEGER DEFAULT 0 NOT NULL',
        'indexed': True
    },
    'fanart_tv': {
        'data': 'INTEGER DEFAULT 0 NOT NULL',
        'indexed': True
    },
    'translation': {
        'data': 'INTEGER DEFAULT 0 NOT NULL',
        'indexed': True
    },
    'language': {
        'data': 'TEXT',
    },
    'deletion': {
        'data': 'INTEGER DEFAULT 0 NOT NULL',
        'indexed': True
    },
}

MOVIE_COLUMNS = {
    'id': {
        'data': 'TEXT PRIMARY KEY',
        'foreign_key': 'baseitem(id)',
    },
    'tmdb_id': {
        'data': 'INTEGER',
        'indexed': True
    },
    'year': {
        'data': 'INTEGER',
        'indexed': True
    },
    'plot': {
        'data': 'TEXT',
    },
    'title': {
        'data': 'TEXT',
    },
    'originaltitle': {
        'data': 'TEXT',
    },
    'duration': {
        'data': 'INTEGER',
    },
    'tagline': {
        'data': 'TEXT',
    },
    'premiered': {
        'data': 'TEXT',
        'indexed': True
    },
    'status': {
        'data': 'TEXT',
    },
    'rating': {
        'data': 'INTEGER',
        'indexed': True
    },
    'votes': {
        'data': 'INTEGER',
        'indexed': True
    },
    'popularity': {
        'data': 'INTEGER',
        'indexed': True
    },
}

TVSHOW_COLUMNS = {
    'id': {
        'data': 'TEXT PRIMARY KEY',
        'foreign_key': 'baseitem(id)',
    },
    'tmdb_id': {
        'data': 'INTEGER',
        'indexed': True
    },
    'year': {
        'data': 'INTEGER',
        'indexed': True
    },
    'plot': {
        'data': 'TEXT',
    },
    'title': {
        'data': 'TEXT',
    },
    'originaltitle': {
        'data': 'TEXT',
    },
    'duration': {
        'data': 'INTEGER',
    },
    'tagline': {
        'data': 'TEXT',
    },
    'premiered': {
        'data': 'TEXT',
        'indexed': True
    },
    'status': {
        'data': 'TEXT',
    },
    'rating': {
        'data': 'INTEGER',
        'indexed': True
    },
    'votes': {
        'data': 'INTEGER',
        'indexed': True
    },
    'popularity': {
        'data': 'INTEGER',
        'indexed': True
    },
    'next_episode_to_air_id': {
        'data': 'TEXT',
    },
    'last_episode_to_air_id': {
        'data': 'TEXT',
    },
    'totalseasons': {
        'data': 'INTEGER',
    },
    'totalepisodes': {
        'data': 'INTEGER',
    },
}

EPISODE_GROUP_COLUMNS = {
    'id': {
        'data': 'TEXT PRIMARY KEY',
        'foreign_key': 'baseitem(id)',
    },
    'tmdb_id': {
        'data': 'TEXT',
        'indexed': True,
        'unique': True,
    },
    'tvshow_id': {
        'data': 'TEXT',
        'foreign_key': 'tvshow(id)',
        'indexed': True
    },
    'plot': {
        'data': 'TEXT',
    },
    'title': {
        'data': 'TEXT',
    },
    'type': {
        'data': 'INTEGER',
    },
}

EPISODE_GROUP_SEASON_COLUMNS = {
    'id': {
        'data': 'TEXT PRIMARY KEY',
        'foreign_key': 'baseitem(id)',
    },
    'tmdb_id': {
        'data': 'TEXT',
        'indexed': True,
        'unique': True,
    },
    'tvshow_id': {
        'data': 'TEXT',
        'foreign_key': 'tvshow(id)',
        'indexed': True,
    },
    'group_id': {
        'data': 'TEXT',
        'foreign_key': 'episode_groups(tmdb_id)',
        'indexed': True,
    },
    'plot': {
        'data': 'TEXT',
    },
    'title': {
        'data': 'TEXT',
    },
    'ordering': {
        'data': 'INTEGER',
    },
    'type': {
        'data': 'INTEGER',
    },
}

EPISODE_GROUP_SEASON_EPISODE_COLUMNS = {
    'id': {
        'data': 'TEXT',
        'foreign_key': 'episode(id)',
        'indexed': True,
        'unique': True,
    },
    'tmdb_id': {
        'data': 'INTEGER',
        'indexed': True,
    },
    'tvshow_id': {
        'data': 'TEXT',
        'foreign_key': 'tvshow(id)',
        'indexed': True,
    },
    'season_group_id': {
        'data': 'TEXT',
        'foreign_key': 'episode_group_seasons(tmdb_id)',
        'indexed': True,
        'unique': True,
    },
    'group_id': {
        'data': 'TEXT',
        'foreign_key': 'episode_groups(tmdb_id)',
        'indexed': True,
    },
    'season': {
        'data': 'INTEGER',
    },
    'episode': {
        'data': 'INTEGER',
    },
    'ordering': {
        'data': 'INTEGER',
    },
}

SEASON_COLUMNS = {
    'id': {
        'data': 'TEXT PRIMARY KEY',
        'foreign_key': 'baseitem(id)',
    },
    'season': {
        'data': 'INTEGER',
    },
    'episode_count': {
        'data': 'INTEGER',
    },
    'year': {
        'data': 'INTEGER',
        'indexed': True
    },
    'plot': {
        'data': 'TEXT',
    },
    'title': {
        'data': 'TEXT',
    },
    'originaltitle': {
        'data': 'TEXT',
    },
    'premiered': {
        'data': 'TEXT',
        'indexed': True
    },
    'status': {
        'data': 'TEXT',
    },
    'rating': {
        'data': 'INTEGER',
        'indexed': True
    },
    'votes': {
        'data': 'INTEGER',
        'indexed': True
    },
    'popularity': {
        'data': 'INTEGER',
        'indexed': True
    },
    'tvshow_id': {
        'data': 'TEXT',
        'foreign_key': 'tvshow(id)',
        'indexed': True
    },
}

EPISODE_COLUMNS = {
    'id': {
        'data': 'TEXT PRIMARY KEY',
        'foreign_key': 'baseitem(id)',
    },
    'episode': {
        'data': 'INTEGER',
    },
    'year': {
        'data': 'INTEGER',
        'indexed': True
    },
    'plot': {
        'data': 'TEXT',
    },
    'title': {
        'data': 'TEXT',
    },
    'originaltitle': {
        'data': 'TEXT',
    },
    'premiered': {
        'data': 'TEXT',
        'indexed': True
    },
    'duration': {
        'data': 'INTEGER',
    },
    'status': {
        'data': 'TEXT',
    },
    'rating': {
        'data': 'INTEGER',
        'indexed': True
    },
    'votes': {
        'data': 'INTEGER',
        'indexed': True
    },
    'popularity': {
        'data': 'INTEGER',
        'indexed': True
    },
    'season_id': {
        'data': 'TEXT',
        'foreign_key': 'season(id)',
        'indexed': True
    },
    'tvshow_id': {
        'data': 'TEXT',
        'foreign_key': 'tvshow(id)',
        'indexed': True
    },
}

BELONGS_COLUMNS = {
    'id': {
        'data': 'TEXT',
        'foreign_key': 'baseitem(id)',
        'indexed': True,
        'unique': True,
    },
    'parent_id': {
        'data': 'TEXT',
        'foreign_key': 'baseitem(id)',
        'indexed': True,
        'unique': True,
    },
}

COLLECTION_COLUMNS = {
    'id': {
        'data': 'TEXT PRIMARY KEY',
        'indexed': True,
        'foreign_key': 'baseitem(id)',
    },
    'tmdb_id': {
        'data': 'INTEGER',
        'indexed': True
    },
    'plot': {
        'data': 'TEXT',
    },
    'title': {
        'data': 'TEXT',
    },
}

RATINGS_COLUMNS = {
    'id': {
        'data': 'TEXT',
        'foreign_key': 'baseitem(id)',
        'indexed': True,
        'unique': True,
    },
    'provider': {
        'data': 'TEXT',
        'unique': True,
    },
    'key': {
        'data': 'TEXT',
        'unique': True,
    },
    'value': {
        'data': '',  # No declared type, so that values keep their own type
    },
}

RATINGS_PROVIDER_COLUMNS = {
    'id': {
        'data': 'TEXT',
        'foreign_key': 'baseitem(id)',
        'indexed': True,
        'unique': True,
    },
    'provider': {
        'data': 'TEXT',
        'unique': True,
    },
    'expiry': {
        'data': 'INTEGER',
    },
}

PERSON_COLUMNS = {
    'id': {
        'data': 'TEXT PRIMARY KEY',
        'foreign_key': 'baseitem(id)',
        'indexed': True,
        'unique': True,
    },
    'tmdb_id': {
        'data': 'INTEGER',
        'indexed': True,
        'unique': True,
    },
    'name': {
        'data': 'TEXT',
    },
    'known_for_department': {
        'data': 'TEXT',
    },
    'gender': {
        'data': 'INTEGER',
    },
    'biography': {
        'data': 'TEXT',
    },
    'birthday': {
        'data': 'TEXT',
    },
    'deathday': {
        'data': 'TEXT',
    },
    'also_known_as': {
        'data': 'TEXT',
    },
    'place_of_birth': {
        'data': 'TEXT',
    },
    'popularity': {
        'data': 'INTEGER',
        'indexed': True
    },
}

CERTIFICATION_COLUMNS = {
    'name': {
        'data': 'TEXT',
    },
    'iso_country': {
        'data': 'TEXT',
        'unique': True,
        'indexed': True,
    },
    'iso_language': {
        'data': 'TEXT',
        'unique': True
    },
    'release_date': {
        'data': 'TEXT',
        'unique': True,
        'indexed': True,
    },
    'release_type': {
        'data': 'TEXT',
        'unique': True,
        'indexed': True,
    },
    'parent_id': {
        'data': 'TEXT',
        'foreign_key': 'baseitem(id)',
        'indexed': True,
        'unique': True
    },
}

VIDEO_COLUMNS = {
    'name': {
        'data': 'TEXT',
    },
    'iso_country': {
        'data': 'TEXT',
        'indexed': True,
    },
    'iso_language': {
        'data': 'TEXT',
        'indexed': True,
    },
    'release_date': {
        'data': 'TEXT',
        'indexed': True,
    },
    'key': {
        'data': 'TEXT',
    },
    'path': {
        'data': 'TEXT',
        'unique': True,
    },
    'content': {
        'data': 'TEXT',
        'indexed': True,
    },
    'parent_id': {
        'data': 'TEXT',
        'foreign_key': 'baseitem(id)',
        'indexed': True,
        'unique': True,
    },
}

GENRE_COLUMNS = {
    'name': {
        'data': 'TEXT',
    },
    'tmdb_id': {
        'data': 'INTEGER',
        'unique': True
    },
    'parent_id': {
        'data': 'TEXT',
        'foreign_key': 'baseitem(id)',
        'indexed': True,
        'unique': True
    },
}

COUNTRY_COLUMNS = {
    'iso_country': {
        'data': 'TEXT',
        'unique': True,
        'foreign_key': 'countries(iso_country)',
    },
    'parent_id': {
        'data': 'TEXT',
        'foreign_key': 'baseitem(id)',
        'indexed': True,
        'unique': True
    },
}

COUNTRIES_COLUMNS = {
    'name': {
        'data': 'TEXT',
    },
    'iso_country': {
        'data': 'TEXT PRIMARY KEY',
        'unique': True
    },
}

LANGUAGE_COLUMNS = {
    'iso_language': {
        'data': 'TEXT',
        'unique': True,
        'foreign_key': 'languages(iso_language)',
    },
    'parent_id': {
        'data': 'TEXT',
        'foreign_key': 'baseitem(id)',
        'indexed': True,
        'unique': True
    },
}

LANGUAGES_COLUMNS = {
    'name': {
        'data': 'TEXT',
    },
    'english_name': {
        'data': 'TEXT',
    },
    'iso_language': {
        'data': 'TEXT PRIMARY KEY',
        'unique': True
    },
}

STUDIO_COLUMNS = {
    'tmdb_id': {
        'data': 'INTEGER',
        'unique': True,
        'foreign_key': 'company(tmdb_id)',
    },
    'parent_id': {
        'data': 'TEXT',
        'foreign_key': 'baseitem(id)',
        'indexed': True,
        'unique': True
    },
}

NETWORK_COLUMNS = {
    'tmdb_id': {
        'data': 'INTEGER',
        'unique': True,
        'foreign_key': 'broadcaster(tmdb_id)',
    },
    'parent_id': {
        'data': 'TEXT',
        'foreign_key': 'baseitem(id)',
        'indexed': True,
        'unique': True
    },
}

COMPANY_COLUMNS = {
    'tmdb_id': {
        'data': 'INTEGER PRIMARY KEY',
        'indexed': True
    },
    'name': {
        'data': 'TEXT',
    },
    'logo': {
        'data': 'TEXT',
    },
    'country': {
        'data': 'TEXT',
    },
}

BROADCASTER_COLUMNS = {
    'tmdb_id': {
        'data': 'INTEGER PRIMARY KEY',
        'indexed': True
    },
    'name': {
        'data': 'TEXT',
    },
    'logo': {
        'data': 'TEXT',
    },
    'country': {
        'data': 'TEXT',
    },
}

CREWMEMBER_COLUMNS = {
    'tmdb_id': {
        'data': 'INTEGER',
        'indexed': True,
        'unique': True
    },
    'role': {
        'data': 'TEXT',
        'unique': True
    },
    'department': {
        'data': 'TEXT',
        'unique': True
    },
    'appearances': {
        'data': 'INTEGER',
        'indexed': True
    },
    'parent_id': {
        'data': 'TEXT',
        'foreign_key': 'baseitem(id)',
        'indexed': True,
        'unique': True
    },
}

CASTMEMBER_COLUMNS = {
    'tmdb_id': {
        'data': 'INTEGER',
        'indexed': True,
        'unique': True
    },
    'role': {
        'data': 'TEXT',
        'unique': True
    },
    'ordering': {
        'data': 'INTEGER',
        'indexed': True
    },
    'appearances': {
        'data': 'INTEGER',
        'indexed': True
    },
    'guest': {
        'data': 'INTEGER',
        'indexed': True
    },
    'parent_id': {
        'data': 'TEXT',
        'foreign_key': 'baseitem(id)',
        'indexed': True,
        'unique': True
    },
}

CUSTOM_COLUMNS = {
    'key': {
        'data': 'TEXT',
        'unique': True
    },
    'value': {
        'data': 'TEXT',
    },
    'parent_id': {
        'data': 'TEXT',
        'foreign_key': 'baseitem(id)',
        'indexed': True,
        'unique': True
    },
}

PROVIDER_COLUMNS = {
    'tmdb_id': {
        'data': 'INTEGER',
        'foreign_key': 'service(tmdb_id)',
        'unique': True
    },
    'availability': {
        'data': 'TEXT',
        'indexed': True
    },
    'iso_country': {
        'data': 'TEXT',
        'indexed': True,
        'unique': True
    },
    'parent_id': {
        'data': 'TEXT',
        'foreign_key': 'baseitem(id)',
        'indexed': True,
        'unique': True
    },
}

SERVICE_COLUMNS = {
    'tmdb_id': {
        'data': 'INTEGER PRIMARY KEY',
        'indexed': True
    },
    'display_priority': {
        'data': 'INTEGER',
        'indexed': True
    },
    'name': {
        'data': 'TEXT',
    },
    'logo': {
        'data': 'TEXT',
    },
}

ART_COLUMNS = {
    'aspect_ratio': {
        'data': 'INTEGER',
    },
    'quality': {
        'data': 'INTEGER',
    },
    'iso_language': {
        'data': 'TEXT',
        'indexed': True,
    },
    'iso_country': {
        'data': 'TEXT',
        'indexed': True,
    },
    'icon': {
        'data': 'TEXT',
        'unique': True,
    },
    'type': {
        'data': 'TEXT',
        'unique': True,
    },
    'extension': {
        'data': 'TEXT',
    },
    'rating': {
        'data': 'INTEGER',
        'indexed': True
    },
    'votes': {
        'data': 'INTEGER',
    },
    'parent_id': {
        'data': 'TEXT',
        'foreign_key': 'baseitem(id)',
        'indexed': True,
        'unique': True,
    },
}

FANART_TV_COLUMNS = {
    'icon': {
        'data': 'TEXT',
        'unique': True,
    },
    'iso_language': {
        'data': 'TEXT',
        'indexed': True,
    },
    'likes': {
        'data': 'INTEGER',
        'indexed': True
    },
    'quality': {
        'data': 'INTEGER',
    },
    'type': {
        'data': 'TEXT',
        'unique': True,
    },
    'extension': {
        'data': 'TEXT',
    },
    'parent_id': {
        'data': 'TEXT',
        'foreign_key': 'baseitem(id)',
        'indexed': True,
        'unique': True,
    },
}

USER_ART_COLUMNS = {
    'type': {
        'data': 'TEXT',
        'unique': True,
    },
    'icon': {
        'data': 'TEXT',
    },
    'parent_id': {
        'data': 'TEXT',
        'indexed': True,
        'unique': True,
    },
}


DEFAULT_ART_COLUMNS = {
    'type': {
        'data': 'TEXT',
        'unique': True,
    },
    'icon': {
        'data': 'TEXT',
    },
    'parent_id': {
        'data': 'TEXT',
        'foreign_key': 'baseitem(id)',
        'indexed': True,
        'unique': True,
    },
}

UNIQUE_ID_COLUMNS = {
    'key': {
        'data': 'TEXT',
        'unique': True,
    },
    'value': {
        'data': 'TEXT',
    },
    'parent_id': {
        'data': 'TEXT',
        'foreign_key': 'baseitem(id)',
        'indexed': True,
        'unique': True,
    },
}

TRANSLATION_COLUMNS = {
    'iso_country': {
        'data': 'TEXT',
        'unique': True,
    },
    'iso_language': {
        'data': 'TEXT',
        'unique': True,
    },
    'plot': {
        'data': 'TEXT',
    },
    'title': {
        'data': 'TEXT',
    },
    'tagline': {
        'data': 'TEXT',
    },
    'parent_id': {
        'data': 'TEXT',
        'foreign_key': 'baseitem(id)',
        'indexed': True,
        'unique': True
    },
}

SIMPLECACHE_COLUMNS = {
    'id': {
        'data': 'TEXT PRIMARY KEY',
        'indexed': True,
        'sync': None
    },
    'item_type': {
        'data': 'TEXT',
        'sync': None
    },
    'tmdb_type': {
        'data': 'TEXT',
        'sync': None,
        'indexed': True
    },
    'tmdb_id': {
        'data': 'INTEGER',
        'sync': None,
        'indexed': True
    },
    'season_number': {
        'data': 'INTEGER',
        'sync': None
    },
    'episode_number': {
        'data': 'INTEGER',
        'sync': None
    },
    'trakt_slug': {
        'data': 'TEXT',
        'sync': None
    },
    'premiered': {
        'data': 'TEXT',
        'sync': None,
        'indexed': True
    },
    'year': {
        'data': 'INTEGER',
        'sync': None,
        'indexed': True
    },
    'title': {
        'data': 'TEXT',
        'sync': None
    },
    'status': {
        'data': 'TEXT',
        'sync': None,
        'indexed': True
    },
    'country': {
        'data': 'TEXT',
        'sync': None,
        'indexed': True
    },
    'certification': {
        'data': 'TEXT',
        'sync': None,
        'indexed': True
    },
    'runtime': {
        'data': 'INTEGER',
        'sync': None,
        'indexed': True
    },
    'trakt_rating': {
        'data': 'INTEGER',
        'sync': None
    },
    'trakt_votes': {
        'data': 'INTEGER',
        'sync': None
    },
    'episode_type': {
        'data': 'TEXT',
        'sync': None
    },
    'plays': {
        'data': 'INTEGER DEFAULT 0',
        'sync': 'SyncWatched',
        'indexed': True
    },
    'aired_episodes': {
        'data': 'INTEGER',
        'sync': 'SyncAiredEpisodes',
        'indexed': True
    },
    'watched_episodes': {
        'data': 'INTEGER',
        'sync': 'SyncWatched',
        'indexed': True
    },
    'reset_at': {
        'data': 'TEXT',
        'sync': 'SyncWatched'
    },
    'last_watched_at': {
        'data': 'TEXT',
        'sync': 'SyncWatched',
        'indexed': True
    },
    'last_updated_at': {
        'data': 'TEXT',
        'sync': 'SyncWatched',
        'indexed': True
    },
    'rating': {
        'data': 'INTEGER',
        'sync': 'SyncRatings'
    },
    'rated_at': {
        'data': 'TEXT',
        'sync': 'SyncRatings'
    },
    'favorites_rank': {
        'data': 'INTEGER DEFAULT 0',
        'sync': 'SyncFavorites'
    },
    'favorites_listed_at': {
        'data': 'TEXT',
        'sync': 'SyncFavorites'
    },
    'favorites_notes': {
        'data': 'TEXT',
        'sync': 'SyncFavorites'
    },
    'watchlist_rank': {
        'data': 'INTEGER DEFAULT 0',
        'sync': 'SyncWatchlist',
        'indexed': True
    },
    'watchlist_listed_at': {
        'data': 'TEXT',
        'sync': 'SyncWatchlist',
        'indexed': True
    },
    'watchlist_notes': {
        'data': 'TEXT',
        'sync': 'SyncWatchlist'
    },
    'collection_last_collected_at': {
        'data': 'TEXT',
        'sync': 'SyncCollection',
        'indexed': True
    },
    'collection_last_updated_at': {
        'data': 'TEXT',
        'sync': 'SyncCollection'
    },
    'playback_progress': {
        'data': 'INTEGER',
        'sync': 'SyncPlayback',
        'indexed': True
    },
    'playback_paused_at': {
        'data': 'TEXT',
        'sync': 'SyncPlayback',
        'indexed': True
    },
    'playback_id': {
        'data': 'INTEGER',
        'sync': 'SyncPlayback',
        'indexed': True
    },
    'progress_watched_hidden_at': {
        'data': 'TEXT',
        'sync': 'SyncHiddenProgressWatched',
        'indexed': True
    },
    'progress_collected_hidden_at': {
        'data': 'TEXT',
        'sync': 'SyncHiddenProgressCollected',
        'indexed': True
    },
    'calendar_hidden_at': {
        'data': 'TEXT',
        'sync': 'SyncHiddenCalendar',
        'indexed': True
    },
    'dropped_hidden_at': {
        'data': 'TEXT',
        'sync': 'SyncHiddenDropped',
        'indexed': True
    },
    'next_episode_id': {
        'data': 'TEXT',
        'sync': 'SyncNextEpisodes',
        'indexed': True
    },
    'next_episode_aired_at': {
        'data': 'TEXT',
        'sync': 'SyncNextEpisodes',
        'indexed': True
    },
    'upnext_episode_id': {
        'data': 'TEXT',
        'sync': 'SyncAllNextEpisodes',
        'indexed': True
    },
}

LACTIVITIES_COLUMNS = {
    'id': {
        'data': 'TEXT PRIMARY KEY',
        'indexed': True
    },
    'data': {
        'data': 'TEXT',
        'sync': None
    },
    'expiry': {
        'data': 'INTEGER',
        'indexed': True
    },
}

STORED_METADATA_COLUMNS = {
    'id': {
        'data': 'TEXT PRIMARY KEY',
        'indexed': True
    },
    'item_id': {
        'data': 'TEXT',
        'foreign_key': 'baseitem(id)',
        'indexed': True
    },
    'family_id': {
        'data': 'TEXT',
        'indexed': True
    },
    'reads_other_items': {
        'data': 'INTEGER DEFAULT 0 NOT NULL',
        'indexed': True
    },
    'data': {
        'data': 'TEXT',
    },
    'used': {
        'data': 'INTEGER',
        'indexed': True
    },
}

STORED_METADATA_STATE_COLUMNS = {
    'id': {
        'data': 'TEXT PRIMARY KEY',
    },
    'data': {
        'data': 'TEXT',
    },
}
