import json
import xbmc
from helper import utils, copy
from . import common

class PhotoAlbum:
    def __init__(self, Library, SQLs):
        self.Library = Library
        self.SQLs = SQLs

    def update_SQLs(self, SQLs): # When paused, databases are closed and re-opened -> Update database
        self.SQLs = SQLs

    def change(self, Item, _):
        EmbyItem = copy.Object(Item)
        common.set_path_filename(Item, self.Library.ServerData['ServerId'], None, False)
        self.SQLs["emby"].add_reference_photoalbum(Item['Id'], Item['LibraryId'], Item['ParentId'], Item['PresentationUniqueKey'], Item['Path'], Item['KodiFullPath'], json.dumps(EmbyItem))
        del EmbyItem
        if utils.DebugLog: xbmc.log(f"EMBY.core.photoalbum (DEBUG): ADD OR REPLACE {Item['Id']}: {Item['Path']}", 1) # DEBUGLOG
        return False

    def remove(self, Item, IncrementalSync):
        self.SQLs["emby"].remove_item(Item['Id'], "photoalbum", Item['LibraryId'])

        if int(IncrementalSync):
            xbmc.log(f"EMBY.core.photoalbum: DELETE {Item['Id']}", 1) # LOGINFO
        elif utils.DebugLog:
            xbmc.log(f"EMBY.core.photoalbum (DEBUG): DELETE {Item['Id']}", 1) # LOGDEBUG

    def userdata(self, Item, IncrementalSync, _UpdateKodiFavorite):
        if int(IncrementalSync):
            xbmc.log(f"EMBY.core.photoalbum: USERDATA {Item['Id']}", 1) # LOGINFO
        elif utils.DebugLog:
            xbmc.log(f"EMBY.core.photoalbum (DEBUG): USERDATA {Item['Id']}", 1) # LOGDEBUG

        return False
